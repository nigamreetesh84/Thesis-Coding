# Results

*LLM:* `Qwen/Qwen2.5-7B-Instruct` | *embedding:* `sentence-transformers/all-MiniLM-L6-v2` | *per-card prompting:* True | *split:* holdout | *profiles (core):* 40 | *run:* 2026-11-06T16:04:05+00:00

## A1 / RQ3: grounded vs ungrounded

| metric | value |
|---|---|
| profiles (n) | 40 |
| decision mode | extract_compare |
| grounded profile accuracy | 1.000 |
| grounded 95% CI (Wilson) | [0.912, 1.0] |
| ungrounded profile accuracy | 0.125 |
| ungrounded 95% CI (Wilson) | [0.055, 0.261] |
| accuracy difference | 0.875 |
| profiles fixed by grounding (b) | 35 |
| profiles broken by grounding (c) | 0 |
| McNemar p-value | 0.000 |
| McNemar exact binomial | False |
| relative error reduction | 1.000 |
| grounded cards returned | 1.000 |
| ungrounded cards returned | 1.000 |
| grounded card accuracy (returned cards) | 1.000 |
| ungrounded card accuracy (returned cards) | 0.756 |
| ungrounded replies kept despite card-name mismatch | 0 |
| meets 0.90 stretch target | True |
| verdict | HYPOTHESIS SUPPORTED |

## RQ1: gold-set classification (RAGAS faithfulness not computed)

| metric | value |
|---|---|
| precision | 1.000 |
| recall | 1.000 |
| f1 | 1.000 |
| accuracy | 1.000 |
| majority_class_accuracy | 0.775 |
| positive_rate_gold | 0.225 |
| positive_rate_predicted | 0.225 |
| cards_returned_rate | 1.000 |

## RQ2: retrieval (proxy relevance = all cards of requested banks; saturated, see EVALUATION_NOTES.md)

| metric | value |
|---|---|
| mean_context_precision | 1.000 |
| mean_context_recall | 1.000 |
| note_proxy | saturated by construction: retrieve_for_profile filters chunks by card metadata |
| dense_precision_at_1 | 0.491 |
| dense_recall_at_1 | 0.164 |
| dense_precision_at_2 | 0.461 |
| dense_recall_at_2 | 0.307 |
| dense_precision_at_3 | 0.381 |
| dense_recall_at_3 | 0.380 |
| dense_precision_at_4 | 0.334 |
| dense_recall_at_4 | 0.442 |

## RQ4: explanation traceability

| metric | value |
|---|---|
| label_consistency_rate | 1.000 |
| citation_validity_rate | 1.000 |
| decline_citation_governs_rate | 1.000 |
| correct_decline_citation_governs_rate | 1.000 |
| n_declines | 248 |
| n_correct_declines | 248 |

## A7: LLM decides vs LLM extracts + code compares (n=40)

| arm | profile accuracy | 95% CI | cards returned | card accuracy (returned) |
|---|---|---|---|---|
| LLM decides (14 Oct design) | 0.375 | [0.242, 0.53] | 1.000 | 0.878 |
| extract + compare (grounded) | 1.000 | [0.912, 1.0] | 1.000 | 1.000 |
| extract + compare (ungrounded) | 0.125 | [0.055, 0.261] | 1.000 | 0.756 |

- McNemar, extract+compare vs LLM decides: b=25 (first arm right only), c=0 (second arm right only), p=1.587e-06
- McNemar, extract+compare grounded vs ungrounded: b=35 (first arm right only), c=0 (second arm right only), p=9.081e-09
- Requirement extraction accuracy, grounded (reads the documents): 1.000 of 8 cards x 5 fields; per field: min_income=1.00, min_age=1.00, min_cibil=1.00, allowed_employment=1.00, relationship_required=1.00
- Requirement extraction accuracy, ungrounded (from memory = threshold hallucination): 0.250 of 8 cards x 5 fields; per field: min_income=0.00, min_age=0.25, min_cibil=0.12, allowed_employment=0.12, relationship_required=0.75

### Error analysis (grounded arm)

| difficulty | profiles | profile accuracy |
|---|---|---|
| borderline | 20 | 1.000 |
| easy | 20 | 1.000 |

| card | tp | fp | fn | tn |
|---|---|---|---|---|
| HDFC Diners Club Black | 0 | 0 | 0 | 40 |
| HDFC Millennia | 10 | 0 | 0 | 30 |
| HDFC MoneyBack+ | 35 | 0 | 0 | 5 |
| HDFC Regalia | 3 | 0 | 0 | 37 |
| SBI Elite | 0 | 0 | 0 | 40 |
| SBI Prime | 2 | 0 | 0 | 38 |
| SBI SimplyCLICK | 4 | 0 | 0 | 36 |
| SBI SimplySAVE | 18 | 0 | 0 | 22 |


## Limitations

See `EVALUATION_NOTES.md` (synthetic oracle-derived gold set, borderline-heavy profiles, hedged documents, class imbalance, tiny corpus, small quantised model, RAGAS not computed).
