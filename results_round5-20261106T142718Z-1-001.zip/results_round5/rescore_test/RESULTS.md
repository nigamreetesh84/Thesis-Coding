# Results

*LLM:* `Qwen/Qwen2.5-7B-Instruct` | *embedding:* `sentence-transformers/all-MiniLM-L6-v2` | *per-card prompting:* True | *split:* test | *profiles (core):* 40 | *run:* 2026-11-06T12:59:40+00:00

## A1 / RQ3: grounded vs ungrounded

| metric | value |
|---|---|
| profiles (n) | 40 |
| decision mode | llm |
| grounded profile accuracy | 0.425 |
| grounded 95% CI (Wilson) | [0.285, 0.578] |
| ungrounded profile accuracy | 0.000 |
| ungrounded 95% CI (Wilson) | [0.0, 0.088] |
| accuracy difference | 0.425 |
| profiles fixed by grounding (b) | 17 |
| profiles broken by grounding (c) | 0 |
| McNemar p-value | 0.000 |
| McNemar exact binomial | True |
| relative error reduction | 0.425 |
| grounded cards returned | 1.000 |
| ungrounded cards returned | 0.719 |
| grounded card accuracy (returned cards) | 0.894 |
| ungrounded card accuracy (returned cards) | 0.652 |
| ungrounded replies kept despite card-name mismatch | 0 |
| meets 0.90 stretch target | False |
| verdict | HYPOTHESIS SUPPORTED |

> Note: relative error reduction equals grounded accuracy because ungrounded accuracy is 0; report the accuracy difference and McNemar b/c instead.

> Warning: the ungrounded arm returned fewer than 95% of the cards; part of its error may be output-format failure, not wrong knowledge.

## RQ1: gold-set classification (RAGAS faithfulness not computed)

| metric | value |
|---|---|
| precision | 0.976 |
| recall | 0.554 |
| f1 | 0.707 |
| accuracy | 0.894 |
| majority_class_accuracy | 0.769 |
| positive_rate_gold | 0.231 |
| positive_rate_predicted | 0.131 |
| cards_returned_rate | 1.000 |

## RQ2: retrieval (proxy relevance = all cards of requested banks; saturated, see EVALUATION_NOTES.md)

| metric | value |
|---|---|
| mean_context_precision | 1.000 |
| mean_context_recall | 1.000 |
| note_proxy | saturated by construction: retrieve_for_profile filters chunks by card metadata |
| dense_precision_at_1 | 0.525 |
| dense_recall_at_1 | 0.175 |
| dense_precision_at_2 | 0.480 |
| dense_recall_at_2 | 0.320 |
| dense_precision_at_3 | 0.384 |
| dense_recall_at_3 | 0.383 |
| dense_precision_at_4 | 0.338 |
| dense_recall_at_4 | 0.448 |

## RQ4: explanation traceability

| metric | value |
|---|---|
| label_consistency_rate | 0.425 |
| citation_validity_rate | 0.991 |
| decline_citation_governs_rate | 0.806 |
| correct_decline_citation_governs_rate | 0.914 |
| n_declines | 278 |
| n_correct_declines | 245 |

### Error analysis (grounded arm)

| difficulty | profiles | profile accuracy |
|---|---|---|
| borderline | 20 | 0.350 |
| easy | 20 | 0.500 |

| card | tp | fp | fn | tn |
|---|---|---|---|---|
| HDFC Diners Club Black | 0 | 0 | 1 | 39 |
| HDFC Millennia | 3 | 0 | 6 | 31 |
| HDFC MoneyBack+ | 22 | 1 | 16 | 1 |
| HDFC Regalia | 1 | 0 | 3 | 36 |
| SBI Elite | 0 | 0 | 1 | 39 |
| SBI Prime | 1 | 0 | 2 | 37 |
| SBI SimplyCLICK | 0 | 0 | 4 | 36 |
| SBI SimplySAVE | 14 | 0 | 0 | 26 |


## Limitations

See `EVALUATION_NOTES.md` (synthetic oracle-derived gold set, borderline-heavy profiles, hedged documents, class imbalance, tiny corpus, small quantised model, RAGAS not computed).
