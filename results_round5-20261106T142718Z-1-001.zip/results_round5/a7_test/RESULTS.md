# Results

*LLM:* `Qwen/Qwen2.5-7B-Instruct` | *embedding:* `sentence-transformers/all-MiniLM-L6-v2` | *per-card prompting:* True | *split:* test | *profiles (core):* 40 | *run:* 2026-11-06T13:26:59+00:00

## A7: LLM decides vs LLM extracts + code compares (n=40)

| arm | profile accuracy | 95% CI | cards returned | card accuracy (returned) |
|---|---|---|---|---|
| LLM decides (14 Oct design) | 0.425 | [0.285, 0.578] | 1.000 | 0.894 |
| extract + compare (grounded) | 1.000 | [0.912, 1.0] | 1.000 | 1.000 |
| extract + compare (ungrounded) | 0.000 | [0.0, 0.088] | 0.875 | 0.836 |

- McNemar, extract+compare vs LLM decides: b=23 (first arm right only), c=0 (second arm right only), p=2.384e-07
- McNemar, extract+compare grounded vs ungrounded: b=40 (first arm right only), c=0 (second arm right only), p=6.984e-10
- Requirement extraction accuracy, grounded (reads the documents): 1.000 of 8 cards x 5 fields; per field: min_income=1.00, min_age=1.00, min_cibil=1.00, allowed_employment=1.00, relationship_required=1.00
- Requirement extraction accuracy, ungrounded (from memory = threshold hallucination): 0.257 of 7 cards x 5 fields; per field: min_income=0.00, min_age=0.29, min_cibil=0.14, allowed_employment=0.14, relationship_required=0.71


## Limitations

See `EVALUATION_NOTES.md` (synthetic oracle-derived gold set, borderline-heavy profiles, hedged documents, class imbalance, tiny corpus, small quantised model, RAGAS not computed).
